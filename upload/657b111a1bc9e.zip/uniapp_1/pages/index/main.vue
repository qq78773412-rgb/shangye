<template>
<view class="container" :style="{backgroundColor:pageinfo.bgcolor}" v-if="isload">
	<block>
		<dp :pagecontent="pagecontent" :menuindex="menuindex" :latitude="latitude" :longitude="longitude" @getdata="getdata"></dp>
		<dp-guanggao :guanggaopic="guanggaopic" :guanggaourl="guanggaourl" :guanggaotype="guanggaotype"></dp-guanggao>
		<dp-tabbar :opt="opt" @getmenuindex="getmenuindex"></dp-tabbar>
	</block>
	<popmsg ref="popmsg"></popmsg>
	<loading v-if="loading"></loading>
	<wxxieyi></wxxieyi>
</view>
</template>
<script>
var app = getApp();
export default {
	data() {
	return {
			opt:{},
			loading:false,
      isload: false,
			menuindex:-1,
			pre_url: app.globalData.pre_url,
			id: 0,
			pageinfo: [],
			pagecontent: [],
			title: "",
			oglist: "", 
			guanggaopic: "",
			guanggaourl: "",
			guanggaotype: "1",
			latitude:'',
			longitude:'',
			area:'',
			mendianid:0,
			
			sysset:{},
			showlevel:2,
			show_location:0,
			curent_address:'',//当前位置: 城市或者收货地址
			arealist:[],
			show_nearbyarea:false,
			ischangeaddress:false,
			nearbyplacelist:[],
			myaddresslist:[],
			isshowalladdress:false,
			placekeyword:'',
			suggestionplacelist:[]
		}
	},
	onLoad: function (opt) {
		this.opt = app.getopts(opt);
		this.getdata();
	},
	onPullDownRefresh:function(e){
		this.isload = false;
		this.getdata();
	},
	onShareAppMessage:function(){
		return this._sharewx({title:this.title});
	},
	onShareTimeline:function(){
		var sharewxdata = this._sharewx({title:this.title});
		var query = (sharewxdata.path).split('?')[1]+'&seetype=circle';
		console.log(sharewxdata)
		console.log(query)
		return {
			title: sharewxdata.title,
			imageUrl: sharewxdata.imageUrl,
			query: query
		}
	},
	onPageScroll: function (e) {
		uni.$emit('onPageScroll',e);
	},
	methods: {
		getdata:function(){
			var that = this;
			var opt = this.opt
			var id = 0;
			if (opt && opt.id) {
			  id = opt.id;
			}
			//读全局缓存的地区信息
			var locationCache =  app.getLocationCache();
			if(locationCache){
				if(locationCache.latitude){
					this.latitude = locationCache.latitude
					this.longitude = locationCache.longitude
				}
				if(locationCache.area){
					this.area = locationCache.area
					this.curent_address = locationCache.address
				}
				if(locationCache.mendian_id){
					this.mendianid = locationCache.mendian_id
				}
			}
			that.loading = true;
			app.get('ApiIndex/index', {id: id,latitude:that.latitude,longitude:that.longitude,area:that.area,mendian_id:that.mendianid,mode:that.opt.mode?that.opt.mode:''}, function (data) {
				that.loading = false;
				that.isload = true;
				uni.stopPullDownRefresh();
			  if (data.status == 2) {
			    //付费查看
			    app.goto('/pages/pay/pay?id='+data.payorderid, 'redirect');
			    return;
			  }
			  if (data.status == 1) {
			    var pagecontent = data.pagecontent;
					that.title = data.pageinfo.title;
					that.oglist = data.oglist;
					that.guanggaopic = data.guanggaopic;
					that.guanggaourl = data.guanggaourl;
					that.guanggaotype = data.guanggaotype;
					that.pageinfo = data.pageinfo;
					that.pagecontent = data.pagecontent;

			    uni.setNavigationBarTitle({
			      title: data.pageinfo.title
			    });
					that.loaded({title:that.title});
					if(that.latitude=='' && that.longitude=='' && data.needlocation){
						app.getLocation(function (res) {
							that.latitude = res.latitude;
							that.longitude = res.longitude;
							that.getdata();
						});
					}
			  } else {
			    if (data.msg) {
			      app.alert(data.msg, function () {
			        if (data.url) app.goto(data.url);
			      });
			    } else if (data.url) {
			      app.goto(data.url);
			    } else {
			      app.alert('您无查看权限');
			    }
			  }
			});
		}
	}
}
</script>
<style>
	.container{width: 100%;min-height: 100vh;}
</style>