(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/dp-luckycollage/dp-luckycollage"],{"05f2":function(t,n,c){"use strict";var r;c.d(n,"b",(function(){return a})),c.d(n,"c",(function(){return o})),c.d(n,"a",(function(){return r}));var a=function(){var t=this,n=t.$createElement,c=(t._self._c,"0"!=t.params.showprice?t.t("color1"):null),r=t.t("color1rgb"),a=t.t("color1"),o="0"!=t.params.showprice?t.t("color1"):null;t.$mp.data=Object.assign({},{$root:{m0:c,m1:r,m2:a,m3:o}})},o=[]},"29c5":function(t,n,c){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={props:{params:{},data:{}}};n.default=r},"7ffa":function(t,n,c){},"8cb7":function(t,n,c){"use strict";c.r(n);var r=c("05f2"),a=c("f53c");for(var o in a)"default"!==o&&function(t){c.d(n,t,(function(){return a[t]}))}(o);c("bf8d");var u,e=c("f0c5"),f=Object(e["a"])(a["default"],r["b"],r["c"],!1,null,null,null,!1,r["a"],u);n["default"]=f.exports},bf8d:function(t,n,c){"use strict";var r=c("7ffa"),a=c.n(r);a.a},f53c:function(t,n,c){"use strict";c.r(n);var r=c("29c5"),a=c.n(r);for(var o in r)"default"!==o&&function(t){c.d(n,t,(function(){return r[t]}))}(o);n["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/dp-luckycollage/dp-luckycollage-create-component',
    {
        'components/dp-luckycollage/dp-luckycollage-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("8cb7"))
        })
    },
    [['components/dp-luckycollage/dp-luckycollage-create-component']]
]);
