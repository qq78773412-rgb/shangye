(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/dp-guanggao/dp-guanggao"],{3046:function(t,n,a){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=getApp(),u={data:function(){return{guanggaostatus:"1",windowHeight:560,isend:!1,cpbtn:!1}},props:{guanggaourl:"",guanggaopic:"",guanggaotype:{default:"1"},param:{ggcover:0,ggskip:0,skiptype:1}},mounted:function(){var n=t.getSystemInfoSync();this.windowHeight=n.windowHeight,"h5"!=a.globalData.platform&&"mp"!=a.globalData.platform||(this.cpbtn=!0),console.log(this.param)},methods:{guanggaoClick:function(){this.guanggaostatus="0"},playend:function(t){this.guanggaostatus="0",this.isend=!0}}};n.default=u}).call(this,a("5486")["default"])},"8c6f":function(t,n,a){"use strict";var u;a.d(n,"b",(function(){return e})),a.d(n,"c",(function(){return o})),a.d(n,"a",(function(){return u}));var e=function(){var t=this,n=t.$createElement;t._self._c},o=[]},"8e20":function(t,n,a){"use strict";a.r(n);var u=a("3046"),e=a.n(u);for(var o in u)"default"!==o&&function(t){a.d(n,t,(function(){return u[t]}))}(o);n["default"]=e.a},a653:function(t,n,a){"use strict";a.r(n);var u=a("8c6f"),e=a("8e20");for(var o in e)"default"!==o&&function(t){a.d(n,t,(function(){return e[t]}))}(o);a("dab1");var i,c=a("f0c5"),r=Object(c["a"])(e["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],i);n["default"]=r.exports},dab1:function(t,n,a){"use strict";var u=a("e685"),e=a.n(u);e.a},e685:function(t,n,a){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/dp-guanggao/dp-guanggao-create-component',
    {
        'components/dp-guanggao/dp-guanggao-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("a653"))
        })
    },
    [['components/dp-guanggao/dp-guanggao-create-component']]
]);
